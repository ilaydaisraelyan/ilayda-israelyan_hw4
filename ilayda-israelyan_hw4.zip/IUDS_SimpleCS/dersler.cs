﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace IUDS_SimpleCS
{
    public partial class dersler : Form
    {
        public dersler()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=polat\sqlexpress01;Initial Catalog=students;Integrated Security=True");

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtLecCode.Text == "" || txtMaxStud.Text == "" || txtLecCredits.Text == "")
                {
                    MessageBox.Show("All Fields Are Compulsory");
                }
                else
                {
                    SqlCommand cmdinsert = new SqlCommand("Insert into dersler values( ' " + txtLecCode.Text + " ','" + txtMaxStud.Text + "','" + txtLecCredits.Text + "' )", con);
                    con.Open();
                    cmdinsert.CommandType = CommandType.Text;
                    cmdinsert.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from dersler", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtlecid.Text == "")
                {
                    MessageBox.Show("Enter lecture Id To Update");
                }
                else
                {
                    SqlCommand cmdupdate = new SqlCommand("Update dersler SET leccode='" + txtLecCode.Text + "',lecmax='" + txtMaxStud.Text + "' ,leccredits='" + txtLecCredits.Text + "'  where lecid=" + txtlecid.Text + "", con);
                    con.Open();
                    cmdupdate.CommandType = CommandType.Text;
                    cmdupdate.ExecuteNonQuery();
                    MessageBox.Show("Data Updated");
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from dersler", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtlecid.Text == "")
                {
                    MessageBox.Show("Enter Student Id To Delete");
                }
                else
                {
                    SqlCommand cmddel = new SqlCommand("Delete dersler where lecid=" + txtlecid.Text + "", con);
                    con.Open();
                    cmddel.CommandType = CommandType.Text;
                    cmddel.ExecuteNonQuery();
                    MessageBox.Show("Data Deleted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from dersler", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }



        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtlecid.Text == "")
                {
                    MessageBox.Show("Enter lecture Id To Search");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Select * From dersler where lecid=" + txtlecid.Text + "", con);
                    con.Open();

                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        txtLecCode.Text = dr[1].ToString();
                        txtMaxStud.Text = dr[2].ToString();
                        txtLecCredits.Text = dr[3].ToString();
                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from dersler", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnResetle_Click(object sender, EventArgs e)
        {
            foreach (Control T in Controls)
            {
                if (T is TextBox)
                {
                    T.Text = "";
                }
            }
        }

        private void dersler_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentsDataSet2.dersler' table. You can move, or remove it, as needed.
            this.derslerTableAdapter1.Fill(this.studentsDataSet2.dersler);
            // TODO: This line of code loads data into the 'studentsDataSet1.dersler' table. You can move, or remove it, as needed.
           

        }
    }
}
