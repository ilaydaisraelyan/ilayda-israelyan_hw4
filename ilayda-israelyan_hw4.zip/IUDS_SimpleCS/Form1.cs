﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace IUDS_SimpleCS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=polat\sqlexpress01;Initial Catalog=students;Integrated Security=True");


        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtStudName.Text == "" || txtStudSurname.Text == "" || txtStudAge.Text == "")
                {
                    MessageBox.Show("All Fields Are Compulsory");
                }
                else
                {
                    SqlCommand cmdinsert = new SqlCommand("Insert into StudDetails values( ' " + txtStudName.Text + " ','" + txtStudSurname.Text + "','" + txtStudAge.Text + "' )", con);
                    con.Open();
                    cmdinsert.CommandType = CommandType.Text;
                    cmdinsert.ExecuteNonQuery();
                    MessageBox.Show("Data Added");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from StudDetails", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtstudid.Text == "")
                {
                    MessageBox.Show("Enter Student Id To Update");
                }
                else
                {
                    SqlCommand cmdupdate = new SqlCommand("Update StudDetails SET StudName='" + txtStudName.Text + "',StudSurname='" + txtStudSurname.Text + "' ,StudAge='" + txtStudAge.Text + "'  where StudId=" + txtstudid.Text + "", con);
                    con.Open();
                    cmdupdate.CommandType = CommandType.Text;
                    cmdupdate.ExecuteNonQuery();
                    MessageBox.Show("Data  Updated");
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from StudDetails", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtstudid.Text == "")
                {
                    MessageBox.Show("Enter Student Id To Delete");
                }
                else
                {
                    SqlCommand cmddel = new SqlCommand("Delete StudDetails where StudId=" + txtstudid.Text + "", con);
                    con.Open();
                    cmddel.CommandType = CommandType.Text;
                    cmddel.ExecuteNonQuery();
                    MessageBox.Show("Data  Deleted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from StudDetails", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtstudid.Text == "")
                {
                    MessageBox.Show("Enter Student Id To Search");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Select * From StudDetails where StudId=" + txtstudid.Text + "", con);
                    con.Open();

                    cmd.CommandType = CommandType.Text;
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        txtStudName.Text = dr[1].ToString();
                        txtStudSurname.Text = dr[2].ToString();
                        txtStudAge.Text = dr[3].ToString();
                    }
                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter("select * from StudDetails", con);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            foreach (Control T in Controls)
            {
                if (T is TextBox)
                {
                    T.Text = "";
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentsDataSet.StudDetails' table. You can move, or remove it, as needed.
            this.studDetailsTableAdapter.Fill(this.studentsDataSet.StudDetails);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            new dersler().Show();
        }
    }
}
